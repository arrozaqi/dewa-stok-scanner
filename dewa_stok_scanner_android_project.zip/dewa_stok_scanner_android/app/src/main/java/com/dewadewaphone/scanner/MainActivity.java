package com.dewadewaphone.scanner;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.util.ArrayDeque;
import java.util.Locale;

/**
 * Dewa Dewa Phone native barcode scanner.
 * Opens the existing Apps Script Web App and routes native scan results into Stock Checking.
 * No JavaScript interface is exposed to the webpage; the app sends one-way JS calls only.
 */
public class MainActivity extends Activity {
    private static final String PREFS = "dewa_stok_scanner_prefs";
    private static final String PREF_URL = "web_app_url";
    private static final int NAVY = Color.rgb(15, 23, 42);
    private static final int ORANGE = Color.rgb(249, 115, 22);
    private static final int MUTED = Color.rgb(100, 116, 139);
    private static final int BG = Color.rgb(248, 250, 252);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ArrayDeque<PendingScan> pendingScans = new ArrayDeque<>();

    private LinearLayout root;
    private WebView webView;
    private TextView statusView;
    private Button scanButton;
    private Button continuousScanButton;
    private boolean continuousScanMode = false;
    private String webAppUrl = "";
    private boolean pageLoaded = false;
    private boolean pumping = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        buildUi();
        webAppUrl = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_URL, "");
        if (isValidExecUrl(webAppUrl)) {
            loadWebApp();
        } else {
            showWelcomePage();
            mainHandler.postDelayed(() -> showUrlSettings(false), 350);
        }
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(16), dp(13), dp(16), dp(12));
        header.setBackgroundColor(NAVY);

        TextView brand = new TextView(this);
        brand.setText("DEWA DEWA PHONE");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(12);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(brand);

        TextView title = new TextView(this);
        title.setText("Barcode Scanner");
        title.setTextColor(Color.WHITE);
        title.setTextSize(23);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = dp(3);
        header.addView(title, titleParams);

        TextView subtitle = new TextView(this);
        subtitle.setText("Scan barcode langsung ke Stock Checking");
        subtitle.setTextColor(Color.rgb(203, 213, 225));
        subtitle.setTextSize(12);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(-1, -2);
        subtitleParams.topMargin = dp(3);
        header.addView(subtitle, subtitleParams);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams controlsParams = new LinearLayout.LayoutParams(-1, -2);
        controlsParams.topMargin = dp(12);

        scanButton = makeButton("▦  Scan Barcode", ORANGE, Color.WHITE);
        scanButton.setOnClickListener(v -> startBarcodeScan());
        controls.addView(scanButton, new LinearLayout.LayoutParams(0, dp(46), 1.25f));

        continuousScanButton = makeButton("Scan Terus: OFF", Color.rgb(22, 101, 52), Color.WHITE);
        continuousScanButton.setOnClickListener(v -> {
            continuousScanMode = !continuousScanMode;
            continuousScanButton.setText(continuousScanMode ? "Scan Terus: ON" : "Scan Terus: OFF");
            setStatus(continuousScanMode ? "Mode scan beruntun aktif. Setelah setiap barcode, kamera dibuka lagi otomatis; tekan Back saat scanner terbuka untuk berhenti." : "Mode scan beruntun nonaktif.", false);
        });
        LinearLayout.LayoutParams continuousParams = new LinearLayout.LayoutParams(0, dp(46), 1.1f);
        continuousParams.leftMargin = dp(6);
        controls.addView(continuousScanButton, continuousParams);

        Button reload = makeButton("Muat Ulang", Color.rgb(51, 65, 85), Color.WHITE);
        reload.setOnClickListener(v -> {
            if (isValidExecUrl(webAppUrl)) {
                pendingScans.clear();
                pageLoaded = false;
                webView.reload();
                setStatus("Memuat ulang web stok…", false);
            } else {
                showUrlSettings(false);
            }
        });
        LinearLayout.LayoutParams reloadParams = new LinearLayout.LayoutParams(0, dp(46), 0.85f);
        reloadParams.leftMargin = dp(6);
        controls.addView(reload, reloadParams);
        header.addView(controls, controlsParams);

        Button settings = makeButton("⚙  Atur URL Web App (.exec)", Color.rgb(30, 41, 59), Color.WHITE);
        settings.setOnClickListener(v -> showUrlSettings(true));
        LinearLayout.LayoutParams settingsParams = new LinearLayout.LayoutParams(-1, dp(40));
        settingsParams.topMargin = dp(7);
        header.addView(settings, settingsParams);

        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        statusView = new TextView(this);
        statusView.setText("Menghubungkan aplikasi…");
        statusView.setTextSize(12);
        statusView.setTextColor(Color.rgb(51, 65, 85));
        statusView.setPadding(dp(12), dp(10), dp(12), dp(10));
        statusView.setBackgroundColor(Color.rgb(241, 245, 249));
        root.addView(statusView, new LinearLayout.LayoutParams(-1, -2));

        webView = new WebView(this);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setLoadsImagesAutomatically(true);
        webSettings.setSupportZoom(false);
        webSettings.setBuiltInZoomControls(false);
        webSettings.setDisplayZoomControls(false);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        webView.setBackgroundColor(Color.WHITE);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (isTrustedGoogleScriptHost(uri.getHost())) return false;
                // Do not navigate the in-app webview to arbitrary sites.
                try {
                    startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageLoaded = false;
                setStatus("Memuat halaman web stok…", false);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                setStatus("Web stok terbuka. Siap scan barcode.", false);
                mainHandler.postDelayed(MainActivity.this::pumpPendingScans, 700);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) {
                    pageLoaded = false;
                    setStatus("Web gagal dimuat. Periksa internet dan URL .exec, lalu tekan Muat Ulang.", true);
                }
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private Button makeButton(String text, int bgColor, int textColor) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(textColor);
        b.setPadding(dp(8), dp(6), dp(8), dp(6));
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(bgColor));
        return b;
    }

    private void showWelcomePage() {
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'></head>" +
                "<body style='font-family:Arial,sans-serif;padding:24px;color:#0f172a;background:#f8fafc'>" +
                "<h2>Hubungkan web stok</h2><p>Tekan <b>Atur URL Web App (.exec)</b> di bagian atas, lalu tempel URL Apps Script milik Dewa Dewa Phone.</p>" +
                "<p>Setelah web terbuka dan data stok termuat, tekan <b>Scan Barcode</b>. Hasil scan akan dikirim ke menu Stock Checking.</p></body></html>";
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
        pageLoaded = false;
    }

    private void showUrlSettings(boolean allowCancel) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(webAppUrl);
        input.setHint("https://script.google.com/macros/s/.../exec");
        input.setTextSize(14);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        int pad = dp(18);
        LinearLayout box = new LinearLayout(this);
        box.setPadding(pad, dp(8), pad, dp(4));
        box.addView(input, new LinearLayout.LayoutParams(-1, -2));
        TextView help = new TextView(this);
        help.setText("Salin URL Web App dari Apps Script: Deploy → Manage deployments → Web app. URL harus berakhiran /exec. Tidak perlu memasukkan API key untuk halaman web yang di-host Apps Script.");
        help.setTextColor(MUTED);
        help.setTextSize(12);
        LinearLayout.LayoutParams helpParams = new LinearLayout.LayoutParams(-1, -2);
        helpParams.topMargin = dp(8);
        box.addView(help, helpParams);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Koneksi web stok")
                .setView(box)
                .setPositiveButton("Simpan & Buka", null);
        if (allowCancel) builder.setNegativeButton("Batal", (dialog, which) -> { });
        AlertDialog dialog = builder.create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String candidate = input.getText().toString().trim().replaceAll("/+$", "");
            if (!isValidExecUrl(candidate)) {
                input.setError("URL harus HTTPS dan berakhiran /macros/s/.../exec");
                return;
            }
            webAppUrl = candidate;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_URL, webAppUrl).apply();
            pendingScans.clear();
            pageLoaded = false;
            dialog.dismiss();
            loadWebApp();
        }));
        dialog.show();
    }

    private boolean isValidExecUrl(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        try {
            URI uri = URI.create(value.trim());
            String path = uri.getPath() == null ? "" : uri.getPath();
            return "https".equalsIgnoreCase(uri.getScheme())
                    && "script.google.com".equalsIgnoreCase(uri.getHost())
                    && path.matches("/macros/s/[^/]+/exec");
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isTrustedGoogleScriptHost(String host) {
        return host != null && ("script.google.com".equalsIgnoreCase(host)
                || "script.googleusercontent.com".equalsIgnoreCase(host));
    }

    private void loadWebApp() {
        if (!isValidExecUrl(webAppUrl)) {
            showWelcomePage();
            showUrlSettings(false);
            return;
        }
        pageLoaded = false;
        setStatus("Membuka web stok Dewa Dewa Phone…", false);
        webView.loadUrl(webAppUrl);
    }

    private void startBarcodeScan() {
        if (!isValidExecUrl(webAppUrl)) {
            showUrlSettings(false);
            return;
        }
        GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
                .enableAutoZoom()
                .build();
        GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(this, options);
        setStatus("Arahkan kamera ke barcode barang…", false);
        scanButton.setEnabled(false);
        scanner.startScan()
                .addOnSuccessListener(barcode -> {
                    scanButton.setEnabled(true);
                    String raw = barcode == null ? null : barcode.getRawValue();
                    if (raw == null || raw.trim().isEmpty()) {
                        setStatus("Barcode terbaca kosong. Coba scan ulang.", true);
                        return;
                    }
                    String code = raw.trim();
                    pendingScans.addLast(new PendingScan(code));
                    setStatus("Barcode terbaca: " + code + ". Mengirim ke Stock Checking…", false);
                    pumpPendingScans();
                    if (continuousScanMode) mainHandler.postDelayed(() -> { if (continuousScanMode) startBarcodeScan(); }, 650);
                })
                .addOnCanceledListener(() -> {
                    scanButton.setEnabled(true);
                    if (continuousScanMode) {
                        continuousScanMode = false;
                        if (continuousScanButton != null) continuousScanButton.setText("Scan Terus: OFF");
                    }
                    setStatus("Pemindaian dihentikan. Kamu bisa scan lagi kapan saja.", false);
                })
                .addOnFailureListener(error -> {
                    scanButton.setEnabled(true);
                    if (continuousScanMode) {
                        continuousScanMode = false;
                        if (continuousScanButton != null) continuousScanButton.setText("Scan Terus: OFF");
                    }
                    String message = error == null ? "Pemindai tidak tersedia." : error.getLocalizedMessage();
                    setStatus("Gagal membuka pemindai Google. Pastikan Google Play services aktif dan internet tersedia. " + message, true);
                });
    }

    private void pumpPendingScans() {
        if (pumping || pendingScans.isEmpty() || webView == null || !pageLoaded) return;
        PendingScan item = pendingScans.peekFirst();
        if (item == null) return;
        pumping = true;
        String code = JSONObject.quote(item.code);
        // Apps Script may render its HTML inside a same-origin frame. Try the main
        // document and reachable child frames instead of incorrectly waiting forever
        // when the top frame does not own the app's JavaScript functions.
        String javascript = "(function(code){" +
                "function send(w,depth){try{" +
                "var d=w.document;" +
                "if(typeof w.openStockCheckModal==='function'&&typeof w.processStockCheckScan==='function'){" +
                "if(typeof w.stockCheckSaved!=='undefined'&&w.stockCheckSaved)return 'SESSION_SAVED';" +
                "if(typeof w.stockCheckSaving!=='undefined'&&w.stockCheckSaving)return 'SESSION_SAVING';" +
                "var overlay=d.getElementById('stockCheckOverlay');if(!overlay)return 'NO_STOCK_CHECK';" +
                "if(!overlay.classList.contains('show'))w.openStockCheckModal();" +
                "var field=d.getElementById('stockCheckInput');if(!field)return 'NO_SCAN_INPUT';" +
                "field.value=code;w.processStockCheckScan(code);return 'SENT';}" +
                "if(depth<4){for(var i=0;i<w.frames.length;i++){var r=send(w.frames[i],depth+1);if(r&&r!=='NO_STOCK_CHECK')return r;}}" +
                "}catch(e){}return 'NO_STOCK_CHECK';}" +
                "try{var result=send(window,0);return result||'APP_NOT_READY';}catch(e){return 'ERROR:'+String(e&&e.message||e);}})(" + code + ")";

        webView.evaluateJavascript(javascript, rawResult -> {
            pumping = false;
            String result = decodeJsResult(rawResult);
            if ("SENT".equals(result)) {
                pendingScans.removeFirst();
                setStatus("Terkirim ke Stock Checking: " + item.code +
                        (pendingScans.isEmpty() ? ". Scan berikutnya siap." : ". Masih ada " + pendingScans.size() + " barcode dalam antrean."), false);
                mainHandler.postDelayed(this::pumpPendingScans, 180);
            } else if ("APP_NOT_READY".equals(result) || "DATA_NOT_READY".equals(result)
                    || "NO_SCAN_INPUT".equals(result) || "SESSION_SAVING".equals(result)) {
                item.attempts++;
                if (item.attempts > 40) {
                    pendingScans.removeFirst();
                    setStatus("Data web belum siap untuk barcode " + item.code + ". Tekan Muat Ulang, tunggu data stok tampil, lalu scan ulang.", true);
                } else {
                    setStatus("Menunggu data stok selesai dimuat sebelum mengirim barcode…", false);
                    mainHandler.postDelayed(this::pumpPendingScans, 600);
                }
            } else if ("SESSION_SAVED".equals(result)) {
                pendingScans.removeFirst();
                setStatus("Sesi Stock Checking sudah disimpan. Klik Sesi baru di halaman web, lalu scan ulang barcode " + item.code + ".", true);
            } else if ("NO_STOCK_CHECK".equals(result)) {
                pendingScans.removeFirst();
                setStatus("Menu Stock Checking tidak ditemukan. Deploy versi web stok yang memiliki fitur Stock Checking, lalu muat ulang.", true);
            } else if (result != null && result.startsWith("ERROR:")) {
                pendingScans.removeFirst();
                setStatus("Web menolak scan: " + result.substring(6), true);
            } else {
                pendingScans.removeFirst();
                setStatus("Scan tidak berhasil dikirim ke web (" + result + "). Muat ulang web dan coba lagi.", true);
            }
        });
    }

    private String decodeJsResult(String raw) {
        if (raw == null) return "";
        try {
            JSONArray array = new JSONArray("[" + raw + "]");
            Object value = array.get(0);
            return value == null ? "null" : String.valueOf(value);
        } catch (Exception ignored) {
            return raw;
        }
    }

    private void setStatus(String message, boolean error) {
        if (statusView == null) return;
        statusView.setText(message);
        statusView.setTextColor(error ? Color.rgb(153, 27, 27) : Color.rgb(51, 65, 85));
        statusView.setBackgroundColor(error ? Color.rgb(254, 226, 226) : Color.rgb(241, 245, 249));
        if (error) Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private static final class PendingScan {
        final String code;
        int attempts = 0;
        PendingScan(String code) { this.code = code; }
    }
}
