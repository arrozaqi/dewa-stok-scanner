# Dewa Dewa Phone — Android Barcode Scanner

Aplikasi Android pendamping untuk web stok Dewa Dewa Phone. Aplikasi ini membuka web app Apps Script yang sudah ada di dalam WebView dan memakai Google Code Scanner native untuk membaca barcode. Hasil scan dikirim langsung ke menu **Stock Checking** pada web app yang terbuka.

## Fitur

- Scan barcode native memakai Google Play services / Google Code Scanner.
- Tidak meminta izin kamera langsung; layar scanner dijalankan oleh Google Play services.
- Mendukung berbagai format barcode melalui `FORMAT_ALL_FORMATS` dan auto-zoom.
- URL Web App `.exec` dapat diatur dari dalam aplikasi dan disimpan di perangkat.
- Barcode yang sudah dipindai dimasukkan ke fungsi `processStockCheckScan()` pada web stok yang sedang dibuka.
- Tidak ada API key hardcoded di APK. APK hanya membuka web app milik pengguna.
- Bila web belum siap, hasil scan diantrikan dan dicoba lagi untuk beberapa saat.

## Persyaratan

- Android 6.0 / API 23 atau lebih baru.
- Google Play services tersedia dan aktif (diperlukan oleh Google Code Scanner).
- URL Web App Google Apps Script yang valid dan dapat dibuka di perangkat.
- Web app harus memakai versi yang memiliki menu **Stock Checking** dengan fungsi JavaScript `openStockCheckModal()` dan `processStockCheckScan()`.

## Cara menggunakan APK setelah dibangun

1. Buka aplikasi **DD Phone Scanner**.
2. Ketuk **Atur URL Web App (.exec)**, lalu tempel URL dari **Apps Script → Deploy → Manage deployments → Web app**. Contohnya format URL `https://script.google.com/macros/s/DEPLOYMENT_ID/exec`.
3. Simpan dan tunggu halaman stok serta daftar produk selesai dimuat.
4. Ketuk **Scan Barcode** dan arahkan kamera ke barcode. Pada penggunaan pertama, Google Play services mungkin perlu mengunduh modul scanner.
5. Setelah barcode terbaca, aplikasi otomatis membuka menu Stock Checking (jika belum terbuka) dan mengirim barcode ke daftar pemeriksaan.
6. Barcode yang belum dikenal akan ditangani oleh web app seperti biasa; tautkan barcode ke produk melalui fitur pemetaan barcode.

## Build di Android Studio

1. Instal Android Studio stable dan SDK Platform 36 / Build Tools 36.0.0.
2. Ekstrak folder proyek ini.
3. Buka folder `dewa_stok_scanner_android` dari Android Studio dan izinkan Gradle melakukan sync serta mengunduh dependensi.
4. Pilih **Build → Build APK(s)**.
5. Debug APK dibuat di `app/build/outputs/apk/debug/app-debug.apk`.

Root project menggunakan Android Gradle Plugin 9.4.0 dan Gradle 9.6.0. Jika versi Android Studio lokal lebih lama, perbarui Android Studio terlebih dahulu.

## Build APK melalui GitHub Actions (alternatif)

Proyek menyertakan `.github/workflows/build-apk.yml` yang membangun APK debug secara otomatis. Untuk memakainya:

1. Buat repository GitHub baru dan unggah seluruh isi proyek (termasuk folder `.github`).
2. Buka tab **Actions**, aktifkan workflows bila GitHub memintanya, lalu jalankan **Build Dewa Stock Scanner APK** melalui **Run workflow**.
3. Setelah status workflow hijau, buka hasil run tersebut dan unduh artifact `dewa-stok-scanner-debug-apk`.
4. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.
5. Kirim APK ke HP, buka file tersebut, dan izinkan instalasi aplikasi dari sumber itu bila Android meminta.

## Keamanan / privasi

- Aplikasi tidak memasukkan API key ke source code atau APK.
- WebView tidak menggunakan `addJavascriptInterface`; aplikasi mengirim barcode melalui evaluasi JavaScript satu arah ke halaman web stok.
- Navigasi WebView dibatasi pada `script.google.com` dan `script.googleusercontent.com`; link eksternal dibuka oleh browser perangkat.
- Akses dan otorisasi data tetap mengikuti deployment Apps Script pengguna.

## Catatan build

Lingkungan pembuatan sumber proyek ini tidak menyediakan Android SDK maupun Gradle dan tidak dapat mengunduh build tools, sehingga APK biner belum dibangun atau diuji dari sini. Proyek dan workflow di atas disiapkan untuk menghasilkan APK debug di Android Studio atau GitHub Actions.
