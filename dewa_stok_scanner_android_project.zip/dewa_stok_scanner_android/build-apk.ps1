$ErrorActionPreference = 'Stop'
$GradleVersion = '9.6.0'
$GradleParent = Join-Path $env:USERPROFILE '.gradle\dewa-stok-scanner'
$GradleHome = Join-Path $GradleParent "gradle-$GradleVersion"
$GradleExe = Join-Path $GradleHome 'bin\gradle.bat'

Write-Host '=== Build APK DEWA DEWA PHONE ===' -ForegroundColor Cyan

# Find Java. Prefer Android Studio's bundled JBR if JAVA_HOME is not set.
if (-not $env:JAVA_HOME -or -not (Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) {
    $Candidates = @(
        (Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Android Studio\jbr'),
        (Join-Path $env:ProgramFiles 'Android\Android Studio\jre')
    )
    $FoundJava = $Candidates | Where-Object { Test-Path (Join-Path $_ 'bin\java.exe') } | Select-Object -First 1
    if ($FoundJava) { $env:JAVA_HOME = $FoundJava }
}
if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME 'bin'))) {
    $env:PATH = (Join-Path $env:JAVA_HOME 'bin') + ';' + $env:PATH
}
try { & java -version 2>&1 | Out-Host } catch { throw 'JDK belum ditemukan. Instal Android Studio atau Java JDK 17+ lalu coba lagi.' }

# Find Android SDK installed by Android Studio.
$Sdk = $env:ANDROID_SDK_ROOT
if (-not $Sdk) { $Sdk = $env:ANDROID_HOME }
if (-not $Sdk) { $Sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not (Test-Path $Sdk)) {
    throw "Android SDK tidak ditemukan di '$Sdk'. Instal Android Studio, lalu di SDK Manager pasang Android SDK Platform 36 dan Android SDK Build-Tools 36.0.0."
}
$Platform = Join-Path $Sdk 'platforms\android-36'
$BuildTools = Join-Path $Sdk 'build-tools\36.0.0'
if (-not (Test-Path $Platform) -or -not (Test-Path $BuildTools)) {
    throw "SDK belum lengkap. Buka Android Studio > Tools > SDK Manager > SDK Platforms dan centang Android 16 / API 36; pada SDK Tools pasang Android SDK Build-Tools 36.0.0."
}
$env:ANDROID_SDK_ROOT = $Sdk
$env:ANDROID_HOME = $Sdk

# Download official Gradle distribution if it is not already cached locally.
if (-not (Test-Path $GradleExe)) {
    Write-Host "Mengunduh Gradle $GradleVersion dari distribusi resmi..." -ForegroundColor Yellow
    New-Item -ItemType Directory -Force -Path $GradleParent | Out-Null
    $Zip = Join-Path $env:TEMP "gradle-$GradleVersion-bin.zip"
    $Extract = Join-Path $env:TEMP "dewa-gradle-extract-$GradleVersion"
    Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $Zip
    if (Test-Path $Extract) { Remove-Item $Extract -Recurse -Force }
    Expand-Archive -Path $Zip -DestinationPath $Extract -Force
    $Source = Join-Path $Extract "gradle-$GradleVersion"
    if (-not (Test-Path (Join-Path $Source 'bin\gradle.bat'))) { throw 'Paket Gradle tidak lengkap setelah diunduh.' }
    if (Test-Path $GradleHome) { Remove-Item $GradleHome -Recurse -Force }
    Move-Item -Path $Source -Destination $GradleHome
    Remove-Item $Extract -Recurse -Force
    Remove-Item $Zip -Force
}

Push-Location $PSScriptRoot
try {
    & $GradleExe --no-daemon assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "Gradle gagal dengan exit code $LASTEXITCODE" }
} finally {
    Pop-Location
}
$Apk = Join-Path $PSScriptRoot 'app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path $Apk)) { throw 'Build selesai tetapi file APK tidak ditemukan.' }
Write-Host ''
Write-Host 'BERHASIL! APK tersedia di:' -ForegroundColor Green
Write-Host $Apk -ForegroundColor Green
